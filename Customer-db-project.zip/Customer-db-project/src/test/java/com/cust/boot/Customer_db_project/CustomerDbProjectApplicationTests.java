package com.cust.boot.Customer_db_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerDbProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
