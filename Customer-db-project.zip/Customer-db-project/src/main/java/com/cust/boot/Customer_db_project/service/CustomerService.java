package com.cust.boot.Customer_db_project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.cust.boot.Customer_db_project.dao.CustomerDao;
import com.cust.boot.Customer_db_project.dto.Customer;
import com.cust.boot.Customer_db_project.util.ResponceStructure;

@Service
public class CustomerService {

	@Autowired
	private CustomerDao customerDao;
	
	
	public ResponceStructure<Customer> saveCustomer(Customer customer)
	{
		customerDao.saveCustomer(customer);
		ResponceStructure<Customer> responceStructure= new ResponceStructure<>();
		responceStructure.setStatusCode(HttpStatus.OK.value());
		responceStructure.setMessage("Customer Saved...");
		responceStructure.setData(customer);
		return responceStructure;
	}
	
	
	
	public ResponceStructure<Customer> findCustomerById(int id)
	{
		Optional<Customer> optional= customerDao.fetchCustomerById(id);
		ResponceStructure<Customer> responceStructure= new ResponceStructure<>();
		
		if(optional.isPresent())
		{
			responceStructure.setStatusCode(HttpStatus.ACCEPTED.value());
			responceStructure.setMessage("Customer Present...");
			responceStructure.setData(optional.get());
			return responceStructure;
		}
		else
		{
			responceStructure.setStatusCode(00000);
			responceStructure.setMessage("Customer Not Present...");
			return responceStructure;
		}
	}
	
	

	
	public ResponceStructure<Customer> updateCustomer(Customer customer)
	{
		customerDao.updateCustomer(customer);
		ResponceStructure<Customer> responceStructure= new ResponceStructure<>();
		responceStructure.setStatusCode(1001);
		responceStructure.setMessage("Customer Data Updated...");
		responceStructure.setData(customer);
		return responceStructure;
	}
	
	
	
	
	public List<Customer> fetchAllData()
	{
		ResponceStructure<Customer> responceStructure= new ResponceStructure<>();
		responceStructure.setStatusCode(200);
		responceStructure.setMessage("Customer Data....");
		return customerDao.fetchAllData();
	}
	
	
	
	
	public ResponceStructure<Customer> deleteCustomer(int id)
	{
		customerDao.deleteCustomer(id);
		ResponceStructure<Customer> responceStructure= new ResponceStructure<>();
		responceStructure.setStatusCode(00000);
		responceStructure.setMessage("Customer Deleted....");
		return responceStructure;
	}
}
