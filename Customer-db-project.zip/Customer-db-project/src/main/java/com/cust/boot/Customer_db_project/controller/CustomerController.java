package com.cust.boot.Customer_db_project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cust.boot.Customer_db_project.dto.Customer;
import com.cust.boot.Customer_db_project.service.CustomerService;
import com.cust.boot.Customer_db_project.util.ResponceStructure;

@RestController
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	
	
	@PostMapping
	public ResponceStructure<Customer> saveCustomer(@RequestBody Customer customer)
	{
		return customerService.saveCustomer(customer);
	}
	
	
	@GetMapping("/{id}")
	public ResponceStructure<Customer> fetchCustomerById(@PathVariable int id)
	{
		return customerService.findCustomerById(id);
	}
	
	
	@PutMapping
	public ResponceStructure<Customer> updateCustomer(@RequestBody Customer customer)
	{
		return customerService.updateCustomer(customer);
	}
	
	
	@GetMapping
	public List<Customer> fetchAllData()
	{
		return customerService.fetchAllData();
	}
	
	
	@DeleteMapping("/{id}")
	public ResponceStructure<Customer> deleteCustomer(@PathVariable int id)
	{
		return customerService.deleteCustomer(id);
	}
	
}
