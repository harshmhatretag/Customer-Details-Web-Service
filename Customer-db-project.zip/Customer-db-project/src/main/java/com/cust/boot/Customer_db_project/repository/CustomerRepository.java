package com.cust.boot.Customer_db_project.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cust.boot.Customer_db_project.dto.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {

}
