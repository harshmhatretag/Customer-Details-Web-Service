package com.cust.boot.Customer_db_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerDbProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerDbProjectApplication.class, args);
	}

}
