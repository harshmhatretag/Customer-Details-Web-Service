package com.cust.boot.Customer_db_project.util;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponceStructure <A> {

	private int statusCode;
	private String message;
	private A data;
}
